import requests
import re
from urllib.parse import urlparse

# Function to check for SQL Injection patterns
def check_sql_injection(url):
    sql_keywords = ['union', 'select', 'insert', 'drop', 'or 1=1', '--']
    for keyword in sql_keywords:
        if keyword.lower() in url.lower():
            return True
    return False

# Function to check if the app is using HTTPS
def check_https(url):
    parsed_url = urlparse(url)
    return parsed_url.scheme == 'https'

# Function to check for potential JavaScript Injection
def check_js_injection(url):
    js_keywords = ['<script>', 'eval(', 'document.cookie', 'alert(']
    try:
        response = requests.get(url)
        response_text = response.text
        for keyword in js_keywords:
            if keyword in response_text:
                return True
    except requests.exceptions.RequestException as e:
        print(f"Error accessing URL: {e}")
    return False

# Function to check for HTTP security headers
def check_http_headers(url):
    headers_to_check = [
        "Strict-Transport-Security", "X-Content-Type-Options", "X-XSS-Protection",
        "Content-Security-Policy", "Referrer-Policy", "Feature-Policy"
    ]
    try:
        response = requests.get(url)
        missing_headers = [header for header in headers_to_check if header not in response.headers]
        return missing_headers
    except requests.exceptions.RequestException as e:
        print(f"Error accessing URL: {e}")
    return []

# Function to check for insecure cookies
def check_secure_cookies(url):
    try:
        response = requests.get(url)
        cookies = response.cookies
        insecure_cookies = []

        # Iterate through cookies
        for cookie in cookies:
            # Check if cookie is secure and HttpOnly
            if not cookie.secure or not cookie.has_nonstandard_attr('HttpOnly'):
                insecure_cookies.append(cookie.name)
        
        return insecure_cookies
    except requests.exceptions.RequestException as e:
        print(f"Error accessing URL: {e}")
    return []

# Function to check if SSL/TLS certificate is expired
def check_ssl_expiry(url):
    try:
        response = requests.get(url, timeout=5)
        cert = response.raw.connection.sock.getpeercert()
        cert_expiry = cert['notAfter']
        return cert_expiry
    except Exception as e:
        print(f"Error retrieving SSL certificate: {e}")
        return None

# Main function to perform security checks
def check_third_party_risk(url):
    risks = []

    # Check if HTTPS is used
    if not check_https(url):
        risks.append("Not using HTTPS (insecure connection)")
    
    # Check for SQL Injection vulnerability
    if check_sql_injection(url):
        risks.append("Possible SQL Injection vulnerability detected")
    
    # Check for JavaScript Injection vulnerability
    if check_js_injection(url):
        risks.append("Possible JavaScript Injection vulnerability detected")
    
    # Check for missing HTTP security headers
    missing_headers = check_http_headers(url)
    if missing_headers:
        risks.append(f"Missing HTTP security headers: {', '.join(missing_headers)}")

    # Check for insecure cookies
    insecure_cookies = check_secure_cookies(url)
    if insecure_cookies:
        risks.append(f"Insecure cookies detected: {', '.join(insecure_cookies)}")
    
    # Check for SSL/TLS certificate expiry
    ssl_expiry = check_ssl_expiry(url)
    if ssl_expiry:
        risks.append(f"SSL certificate expires on: {ssl_expiry}")
    
    # Report result
    if risks:
        print(f"Security risks found for {url}:")
        for risk in risks:
            print(f"- {risk}")
    else:
        print(f"No immediate security risks found for {url}")

# Example usage with user input:
if __name__ == "__main__":
    # Prompt user for the URL
    url_to_check = input("Enter the website URL to check (e.g., https://www.example.com): ")
    
    check_third_party_risk(url_to_check)
