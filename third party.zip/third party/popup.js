document.getElementById("scanBtn").addEventListener("click", function () {
  let url = document.getElementById("urlInput").value.trim();
  let resultsDiv = document.getElementById("results");

  if (!url) {
    resultsDiv.innerHTML = "<p style='color: red;'>⚠️ Please enter a valid URL!</p>";
    return;
  }

  resultsDiv.innerHTML = "<p style='color: yellow;'>🔍 Scanning...</p>";

  // Simulate scanning process
  setTimeout(() => {
    resultsDiv.innerHTML = `
          <p><strong>✅ Scan Complete!</strong></p>
          <p>🛑 SQL Injection: <span style="color: red;">Detected</span></p>
          <p>⚠️ JS Injection: <span style="color: yellow;">Possible</span></p>
          <p>✅ HTTP Headers Secure: <span style="color: green;">Yes</span></p>
          <p><strong>🔧 Recommended Fix:</strong> Sanitize input & implement Content Security Policy (CSP).</p>
      `;
  }, 2000);
});
