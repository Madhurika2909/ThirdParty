// Function to check for SQL Injection patterns
function checkSqlInjection(url) {
    const sqlKeywords = ['union', 'select', 'insert', 'drop', 'or 1=1', '--'];
    for (const keyword of sqlKeywords) {
        if (url.toLowerCase().includes(keyword)) {
            return true;
        }
    }
    return false;
}

// Function to check if the app is using HTTPS
function checkHttps(url) {
    const parsedUrl = new URL(url);
    return parsedUrl.protocol === 'https:';
}

// Function to check for JavaScript Injection
function checkJsInjection(url) {
    const jsKeywords = ['<script>', 'eval(', 'document.cookie', 'alert('];
    return fetch(url)
        .then((response) => response.text())
        .then((text) => {
            for (const keyword of jsKeywords) {
                if (text.includes(keyword)) {
                    return true;
                }
            }
            return false;
        })
        .catch(() => false);
}

// Function to check for HTTP security headers
function checkHttpHeaders(url) {
    const headersToCheck = [
        "Strict-Transport-Security", "X-Content-Type-Options", "X-XSS-Protection",
        "Content-Security-Policy", "Referrer-Policy", "Feature-Policy"
    ];
    return fetch(url)
        .then((response) => {
            const missingHeaders = headersToCheck.filter(header => !(header in response.headers));
            return missingHeaders;
        })
        .catch(() => []);
}

// Function to check for SSL/TLS certificate expiry
function checkSslExpiry(url) {
    return fetch(url, { method: 'HEAD' })
        .then(response => {
            const cert = response.connection.getPeerCertificate();
            return cert.notAfter;
        })
        .catch(() => null);
}

// Function to check for insecure cookies
function checkInsecureCookies(url) {
    return fetch(url)
        .then(response => {
            const cookies = response.headers.get('set-cookie');
            const insecureCookies = [];
            if (cookies && (!cookies.includes('Secure') || !cookies.includes('HttpOnly'))) {
                insecureCookies.push(cookies);
            }
            return insecureCookies;
        })
        .catch(() => []);
}

// Handle security check request from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'checkSecurity') {
        const { url } = message;

        const promises = [
            checkHttps(url),
            checkSqlInjection(url),
            checkJsInjection(url),
            checkHttpHeaders(url),
            checkInsecureCookies(url),
            checkSslExpiry(url)
        ];

        Promise.all(promises).then(results => {
            let resultMessage = '';
            if (!results[0]) resultMessage += "Not using HTTPS (insecure connection)\n";
            if (results[1]) resultMessage += "Possible SQL Injection vulnerability detected\n";
            if (results[2]) resultMessage += "Possible JavaScript Injection vulnerability detected\n";
            if (results[3].length) resultMessage += `Missing HTTP headers: ${results[3].join(', ')}\n`;
            if (results[4].length) resultMessage += `Insecure cookies detected: ${results[4].join(', ')}\n`;
            if (results[5]) resultMessage += `SSL certificate expires on: ${results[5]}\n`;

            if (!resultMessage) resultMessage = 'No immediate security risks found.';

            sendResponse({ message: resultMessage });
        });
        return true;
    }
});
